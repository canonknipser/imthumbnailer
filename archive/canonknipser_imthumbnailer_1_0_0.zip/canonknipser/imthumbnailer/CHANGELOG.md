# Changelog

(newest entries on top)


## 1.0.0-beta1 - 2018-11-24

- First release
