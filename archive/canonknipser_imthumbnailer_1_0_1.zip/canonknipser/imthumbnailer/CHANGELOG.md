# Changelog

(newest entries on top)


## 1.0.1 - 2018-12-24

- improved error handling
- fixed some minor validation issues
- rotate thumbnails according to their exif informations

## 1.0.0-beta1 - 2018-11-24

- First release
